package arithmetic_calculator;

//created a public class for all the basic operations
public class arithmetic_operations {

	 double num1=0, num2=0, answer=0;

	 //creating different methods for arithmetic operations
	    public void add(){
	        answer = num1 + num2;
	        
	    }

	    public void sub(){
	        answer = num1 - num2;
	        System.out.println(answer);
	    }

	    public void div(){
	        answer = num1 / num2;
	        System.out.println(answer);
	    }

	    public void mul(){
	        answer = num1 * num2;
	        System.out.println(answer);
	    }
}
