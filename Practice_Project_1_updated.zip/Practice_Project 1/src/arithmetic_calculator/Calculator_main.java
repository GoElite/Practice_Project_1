package arithmetic_calculator;

import java.util.Scanner;

public class Calculator_main {

	public static void main(String[] args) {
		
//call arithemetic_operations class	in the main class	
		arithmetic_operations opt = new arithmetic_operations();

		
		int operation;

//using while loop to perform the operations repeatedly
        while(true)
        {
        	//getting input from user
            Scanner s = new Scanner(System.in);
            System.out.print("Enter first number:");
            opt.num1 = s.nextInt();
            System.out.print("Enter second number:");
            opt.num2 = s.nextInt();
        	
            //using printf (print formatted) to print the statement & %n to print statement in next line
            System.out.printf("%nEnter 1 for Addition "
            		+ "%nEnter 2 for Subtraction "
            		+ "%nEnter 3 for Multiplication "
            		+ "%nEnter 4 for Division "
            		+ "%nEnter 5 to Exit "
            		+ "%n%nEnter the operation number =  ");
            
            //using switch-case
            operation = s.nextInt();
            switch(operation)
            {
                case 1:
                opt.add();
                System.out.println("Addition = "+opt.answer);
                break;
 
                case 2:
                opt.sub();
                System.out.println("Subtraction = "+opt.answer);
                break;
 
                case 3:
                opt.mul();
                System.out.println("Multiplication = "+opt.answer);
                break;
 
                case 4:
                opt.div();
                System.out.println("Division = "+opt.answer);
                break;    
 
                case 5:
                System.exit(0);
            }
            
        }
        
	}
	
	       
}
		
		

	
	


