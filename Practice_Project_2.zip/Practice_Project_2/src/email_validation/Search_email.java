package email_validation;

import java.util.ArrayList;
import java.util.Scanner;

public class Search_email {

    public static void main(String[] args) {

// creating array list of valid Email ID        
    	ArrayList<String> email_id = new ArrayList<String>();
        
		email_id.add("shivam@onego.com"
		+"aditya@onego.com"
		+"ayush@onego.com"
		+"diksha@onego.com"
		+"shamika@onego.com"
		+"gaurav@onego.com"
		+"tanmay@onego.com");

        String Search_email = new String();
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the E-mail id to verify: ");
        Search_email = sc.next();
		
// if-else condition applied to check the correct email id
        
                    if(email_id.contains(Search_email)){
                    	
                    	System.out.println(Search_email + " - Email ID Found");
                    	
                    }
                    else{
                    	System.out.println(Search_email + " - Email ID Found");

                  
                }
    		}
		}