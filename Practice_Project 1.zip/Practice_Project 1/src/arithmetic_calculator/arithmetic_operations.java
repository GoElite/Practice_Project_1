package arithmetic_calculator;

public class arithmetic_operations {

	 double num1=0, num2=0, answer=0;

	    public void add(){
	        answer = num1 + num2;
	        
	    }

	    public void sub(){
	        answer = num1 - num2;
	        System.out.println(answer);
	    }

	    public void div(){
	        answer = num1 / num2;
	        System.out.println(answer);
	    }

	    public void mul(){
	        answer = num1 * num2;
	        System.out.println(answer);
	    }
}
