package arithmetic_calculator;

import java.util.Scanner;

public class Calculator_main {

	public static void main(String[] args) {
		
		//call arithemetic_operations class		
		arithmetic_operations opt = new arithmetic_operations();

		
		int operation;

        while(true)
        {
            Scanner s = new Scanner(System.in);
            System.out.print("Enter first number:");
            opt.num1 = s.nextInt();
            System.out.print("Enter second number:");
            opt.num2 = s.nextInt();
        	
        	
            System.out.printf("Enter 1 for addition "
            		+ "%nEnter 2 for subtraction "
            		+ "%nEnter 3 for multiplication "
            		+ "%nEnter 4 for division "
            		+ "%nEnter 5 to Exit ");

            operation = s.nextInt();
            switch(operation)
            {
                case 1:
                opt.add();
                System.out.println("Addition = "+opt.answer);
                break;
 
                case 2:
                opt.sub();
                System.out.println("Subtraction = "+opt.answer);
                break;
 
                case 3:
                opt.mul();
                System.out.println("Multiplication = "+opt.answer);
                break;
 
                case 4:
                opt.div();
                System.out.println("Division = "+opt.answer);
                break;    
 
                case 5:
                System.exit(0);
            }
            
        }
        
	}
	
	       
}
		
		

	
	


